package edu.bit.ex;

public class CircleArea implements Ishape{
	
	 private double radius;

	
	public CircleArea(double radius) {
		super();
		this.radius = radius;
	}


	public CircleArea() {}
	
	
	
	
	public double getRadius() {
		return radius;
	}


	public void setRadius(double radius) {
		this.radius = radius;
	}


	@Override
	public double getArea() {
		return radius*(Math.PI);
	}
	
}
