package edu.bit.ex;


import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configurable
public class Config {
	
	@Bean
	public Ishape recBean() {
		Ishape rec = new RectangleArea(5,5);
		return rec;
	}
	
	@Bean
	public Ishape triBean() {
		Ishape tri = new TriangleArea(5,5);
		return tri;
	}
	
	@Bean
	public Ishape cirBean() {
		Ishape cir = new CircleArea(5);
		return cir;
	}
	
}
