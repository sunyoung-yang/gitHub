package edu.bit.ex;

public interface Ishape {

	public double getArea();
	
}
