package edu.bit.ex;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class MainClass {

	public static void main(String[] args) {


		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class);
		RectangleArea recBean = ctx.getBean("recBean",RectangleArea.class);
		System.out.println(recBean.getArea());
		
		recBean.setWidth(10);
		recBean.setHeight(10);
		System.out.println(recBean.getArea());
		
		
		
		Ishape triBean = ctx.getBean("triBean",TriangleArea.class);
		System.out.println(triBean.getArea());
		
		CircleArea cirBean = ctx.getBean("cirBean",CircleArea.class);
		System.out.println(cirBean.getArea());
		cirBean.setRadius(10);
		System.out.println(cirBean.getArea());
		
		ctx.close();
	}

}
