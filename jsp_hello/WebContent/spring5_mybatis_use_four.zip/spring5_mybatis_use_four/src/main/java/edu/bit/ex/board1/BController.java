package edu.bit.ex.board1;

import java.sql.Timestamp;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
/*
1. interface IBDao�� xml namespace�� ����
2. sqlSession.getMapper(IBDao.class)�� �̿�.
*/

@Controller
public class BController {
	
	@Inject
	BService bservice;	//���̹�Ƽ�� 
	
	
	@RequestMapping("/list")
	public String list(Model model) throws Exception {
		System.out.println("list()");
		
		model.addAttribute("list",bservice.selectBoardList());
		
		return "list";
	}

}
