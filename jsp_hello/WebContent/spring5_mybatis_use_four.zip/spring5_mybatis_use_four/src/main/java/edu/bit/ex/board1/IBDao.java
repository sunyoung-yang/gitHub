package edu.bit.ex.board1;

import java.sql.Timestamp;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


public interface IBDao {
	
	public List<BDto> listDao();
	
	

}
