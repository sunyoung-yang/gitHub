package edu.bit.ex.board4;

import java.sql.Timestamp;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class BController4 {
	
	@Inject
	BService4 bservice4;	//���̹�Ƽ�� 
	
	
	@RequestMapping("/list4")
	public String list(Model model) throws Exception {
		System.out.println("list4()");
		
		model.addAttribute("list",bservice4.selectBoardList());
		
		return "list";
	}

}
