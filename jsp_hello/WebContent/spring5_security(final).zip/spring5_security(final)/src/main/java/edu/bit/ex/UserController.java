package edu.bit.ex;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import edu.bit.ex.service.UserService;
import edu.bit.ex.vo.UserVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;


@Controller
@Log4j
@AllArgsConstructor
public class UserController {
//ȸ������	
	private UserService service;
	
	@GetMapping(value="/user/userForm")
	public void loginFor() {
		log.info("loginFor()");
	}
	  
	@PostMapping("/user/addUser")
	public String addUser(UserVO userVO) {
		log.info("addUser()");
		
		service.addUser(userVO);
		return "redirect:/";
				
	}
}
