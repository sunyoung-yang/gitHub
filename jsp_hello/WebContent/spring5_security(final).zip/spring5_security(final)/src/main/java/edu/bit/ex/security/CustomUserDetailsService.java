package edu.bit.ex.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import edu.bit.ex.mapper.EmpMapper;
import edu.bit.ex.vo.CustomUser;
import edu.bit.ex.vo.EmpVO;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service	//mapper�ҷ����ϱ� ���񽺶� ġ�°ž�
public class CustomUserDetailsService implements UserDetailsService{

//������ �� �ٸ� �������� �ҷ����� ����!	
	
	@Setter(onMethod_ = @Autowired)
	private EmpMapper mapper;
	
	@Override	//UserDetailsService ����? loadUserByUsername�갡 ��񰬴ٰ� userDetails����
	public UserDetails loadUserByUsername(String ename) throws UsernameNotFoundException {
	
		log.warn("load user by employee number: "+ename);
		
		EmpVO vo = mapper.readUser(ename);
		
		log.warn("queried by empVO mapper: "+vo );
				
		
		return vo ==null ? null : new CustomUser(vo);
	}
	
	
	
}
