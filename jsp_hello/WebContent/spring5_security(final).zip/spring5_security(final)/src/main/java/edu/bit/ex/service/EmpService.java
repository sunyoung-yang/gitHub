package edu.bit.ex.service;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.bit.ex.vo.EmpVO;
import edu.bit.ex.vo.UserVO;
import edu.bit.ex.mapper.EmpMapper;
import edu.bit.ex.mapper.UserMapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Log4j
@NoArgsConstructor
@Service
public class EmpService {
	
//emp�� users���̺��� �޸� CustomNoOpPasswordEncoder�� ����� ���ڵ�
	
	
	
	@Inject
	private EmpMapper empMapper;
	
	public EmpVO getUser(String empNo){
		log.info("readUser .. ");
		return empMapper.readUser(empNo);
	}
}