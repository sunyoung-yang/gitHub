package edu.bit.ex;

public interface Area {
	
	public double getArea();

}
