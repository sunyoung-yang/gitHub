package edu.bit.ex;

public class RectangleArea implements Area{
	
	double width;
	double height;
	
	public RectangleArea() {}
	
	public RectangleArea(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}

	@Override
	public double getArea() {
		return width*height;
	}

	

}
