package edu.bit.ex;

public class TriangleArea implements Area{
	
	private double width;
	private double height;
	
	public TriangleArea() {}
	
	public TriangleArea(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}

	@Override
	public double getArea() {
		return (width*height)/2;
	}

	

}
