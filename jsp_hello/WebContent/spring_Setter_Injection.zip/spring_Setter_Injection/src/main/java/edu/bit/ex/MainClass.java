package edu.bit.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		String config = "classpath:apppencilCTX.xml";
		AbstractApplicationContext ctx = new GenericXmlApplicationContext(config);
		
		Area area = ctx.getBean("recArea",Area.class);
		System.out.println(area.getArea());
		
		area = ctx.getBean("triArea",Area.class);
		System.out.println(area.getArea());
		ctx.close();
	
	}
	
}
