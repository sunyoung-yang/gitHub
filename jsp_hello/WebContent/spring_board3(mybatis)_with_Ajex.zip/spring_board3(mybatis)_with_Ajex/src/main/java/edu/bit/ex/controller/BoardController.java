package edu.bit.ex.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.bit.ex.aop.LogAdvice;
import edu.bit.ex.service.BoardService;
import edu.bit.ex.vo.BoardVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;


@AllArgsConstructor
@Controller
@Log4j // �ڵ����� �α� ����
public class BoardController {
	
	//������5 �����ڰ� ������ auto(�ڵ����� �־���)
	private BoardService service; // ���񽺿��� ����Ͻ������� ����.

	
	@GetMapping("/list") // list�� �ٹ������ �ްڴٴ� �ǹ�
	public void list(Model model) {
		log.info("list");
		model.addAttribute("list", service.getList());
	}

	
	@GetMapping("/content_view")
	public String content_view(BoardVO board, Model model) {
		log.info("content_view");

		model.addAttribute("content_view", service.get(board.getbId()));

		return "content_view";
	}

	@GetMapping("/delete")
	public String delete(BoardVO board) {
		log.info("delete");

		service.remove(board.getbId());

		return "redirect:list";
	}

	@RequestMapping("/write_view")
	public String write_view() {
		log.info("write_view");

		return "write_view";
	}

	@RequestMapping("/write")
	public String write(BoardVO board) throws Exception {
		log.info("write");

		service.writeBoard(board);

		return "redirect:list";
	}

	@RequestMapping("/modify")
	public String modify(BoardVO board) throws Exception {
		log.info("modify");

		service.modify(board);

		return "redirect:list";
	}

	@RequestMapping("/reply_view")
	public String reply_view(BoardVO board, Model model) {
		log.info("reply_view");

		model.addAttribute("reply_view", service.replyView(board.getbId()));

		return "reply_view";
	}

	@RequestMapping("/reply")
	public String reply(BoardVO board) throws Exception {
		log.info("reply");

		service.reply(board);

		return "redirect:list";
	}
	
	@GetMapping("/listjquery") // list�� �ٹ������ �ްڴٴ� �ǹ�
	public String listquery(Model model) {
		log.info("listquery");
		model.addAttribute("list", service.getList());
		return "listjquery";
	}
	
	
	@RequestMapping("/ajex/list") // list�� �ٹ������ �ްڴٴ� �ǹ�
	public String ajexList() {
		log.info("ajexList()");
		return "ajexList";
	}

	

}
