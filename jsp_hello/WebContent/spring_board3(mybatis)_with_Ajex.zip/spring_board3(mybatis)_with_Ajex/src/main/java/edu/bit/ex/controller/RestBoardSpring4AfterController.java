package edu.bit.ex.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import edu.bit.ex.aop.LogAdvice;
import edu.bit.ex.service.BoardService;
import edu.bit.ex.vo.BoardVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;

//spring v4.0 ���� ���� (@Controller + @ResponseBody)

@AllArgsConstructor
@RestController	//(controller + @ResponseBody)		
@Log4j
public class RestBoardSpring4AfterController {

	private BoardService service;

	//before�� �ִ� @ResoponseBody �����
	@RequestMapping("/restful/after")
	@CrossOrigin //������ó��Ģ ���������� �ٸ� ��ó���� �������ϸ� ������ ���� ������!
	public List<BoardVO> before() {
		
		log.info("/restful/after");
		List<BoardVO> list = service.getList();

		return list;
	}

}