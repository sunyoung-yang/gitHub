package edu.bit.ex.service;

import java.util.List;

import edu.bit.ex.vo.BoardVO;

public interface BoardService {

	public List<BoardVO> getList();

	public BoardVO get(int bno);

	public void remove(int bno);

	public void writeBoard(BoardVO board);

	public BoardVO replyView(int bno);

	public void reply(BoardVO board);

	public void modify(BoardVO board);


}
