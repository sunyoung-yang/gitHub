package edu.bit.ex.service;

import java.util.List;

import org.springframework.stereotype.Service;

import edu.bit.ex.mapper.LogInMapper;
import edu.bit.ex.vo.UserVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;



@Log4j
@Service
@AllArgsConstructor			//�ڵ� ����ȭ�� ����
public class LogInService {
	
	LogInMapper mapper;
	
	public UserVO user(String id,String pw) {
		return mapper.logInUser(id,pw);
	}
	}



	


	
	
	


