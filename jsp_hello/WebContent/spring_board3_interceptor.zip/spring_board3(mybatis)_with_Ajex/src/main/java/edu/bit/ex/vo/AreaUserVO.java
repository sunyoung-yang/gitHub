package edu.bit.ex.vo;

import java.sql.PreparedStatement;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor //��� �˱Ը�Ʈ �޾Ƴ��°�
@NoArgsConstructor  //�˱Ը�Ʈ ���°� �޾Ƴ��°�
@Data
public class AreaUserVO {
	
	
	String id;
	String pw;
	String name;
	String phone1;
	String phone2;
	String phone3;
	String gender;


	
	
}
