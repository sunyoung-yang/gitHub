package edu.bit.ex.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AreaVO {

	double width;
	double height;
	
	public double getArea() {
		return width*height;
	}
}
