package edu.bit.ex.vo;

import java.sql.PreparedStatement;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor //��� �˱Ը�Ʈ �޾Ƴ��°�
@NoArgsConstructor  //�˱Ը�Ʈ ���°� �޾Ƴ��°�
@Data
public class UserVO {
	
	private int bId;
	String username;
	String password;
	char enabled;


	
	
}
