package edu.bit.ex.aop;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import edu.bit.ex.service.BoardService;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringRunner.class)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
						"file:src/main/webapp/WEB-INF/spring/aop-context.xml"}) //�� ����!(���� ����) //aop-context.xml�� ����
@Log4j
public class AopTest {

	
	@Inject
	private BoardService service;
	
	@Test
	public void testServiceAop() {
		//log.info(service.getClass().getName());
		log.info("����Ʈ ����");
		log.info(service.getList());
		log.info("����Ʈ ��");
	}
	
	
	
	

}
