package edu.bit.board.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.bit.board.command.BCommand;
import edu.bit.board.command.BListCommand;


@Controller
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	
	private BCommand command=null;
	
	@RequestMapping("/list")
	public String list(Model model) {
		System.out.println("list");
		
		command=new BListCommand();
		command.execute(model);
		
		return "list";
	}
	
}
