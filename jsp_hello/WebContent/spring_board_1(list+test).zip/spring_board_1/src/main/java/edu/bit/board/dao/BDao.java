package edu.bit.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import edu.bit.board.dto.BDto;

public class BDao {
	
	private DataSource dataSource;	//connection pool
		
	public BDao() {	//�׽�Ʈ �� �غ��� ��!
		try {
		Context context = new InitialContext();
		dataSource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	
	public ArrayList<BDto> list(){
		
		ArrayList<BDto> dtos = new ArrayList<BDto>();
		
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet res = null;
		
		String query="select * from mvc_board order by bGroup desc, bStep asc";
											//�ֽ� ����� ���� �ö�;��ϴϱ� bStep asc
		
		try {
			con = dataSource.getConnection();
			pre=con.prepareStatement(query);
			res = pre.executeQuery();
			
			while(res.next()) {
				int bId = res.getInt("bId");
				String bName = res.getString("bName");
				String bTitle = res.getString("bTitle");
				String bContent= res.getString("bContent");
				Timestamp bDate = res.getTimestamp("bDate");
				int bHit= res.getInt("bHit");
				int bGroup= res.getInt("bGroup");
				int bStep= res.getInt("bStep");
				int bIndent= res.getInt("bIndent");
				
				BDto dto = new BDto(bId,bName,bTitle,bContent,bDate,bHit,bGroup,bStep,bIndent);
				dtos.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			
		try {
			if(res != null) {res.close();}
			if(pre != null) {pre.close();}
			if(con != null) {con.close();}
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		}
		
		
		return dtos;
	}
	
	
	
	
	
	
	
	
	

}
