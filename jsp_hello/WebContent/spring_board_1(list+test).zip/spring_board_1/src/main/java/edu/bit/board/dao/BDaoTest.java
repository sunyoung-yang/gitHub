package edu.bit.board.dao;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.junit.Test;

import edu.bit.board.dto.BDto;

public class BDaoTest {

	@Test
	public void BDaotest() {
	
		BDao dao = new BDao();
		System.out.println(dao);
		
		
	}
	
	@Test
	public void BDaoListtest() {

		BDao dao = new BDao();
		ArrayList<BDto> dtos = new ArrayList<BDto>();
		
		for(BDto bdto : dtos) {
			System.out.println(bdto.getBId());
		}
			
			
			
		assertNotNull(dao.list());
		
		
	}

}
