package edu.bit.ex.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import edu.bit.ex.mapper.EMPMapper;
import edu.bit.ex.vo.BoardVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ServiceEMPImpl implements ServiceEMP {
	
	private EMPMapper mapper;
	
	@Override
	public List<BoardVO> getEMPList(BoardVO boardVO){
		log.info("Service.list����");
		
		return mapper.getList(boardVO);
	}

	

}
