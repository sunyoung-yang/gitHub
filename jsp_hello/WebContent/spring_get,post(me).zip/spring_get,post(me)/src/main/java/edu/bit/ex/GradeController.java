package edu.bit.ex;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class GradeController {
	
	private static final Logger logger = LoggerFactory.getLogger(GradeController.class);
	
	/*
	 * @RequestMapping("/grade") public String grade(Grade grade) { return "grade";
	 * }
	 */
	@RequestMapping("/index")
	public String goIndex() {
		return "index";
	}
	
	@RequestMapping(value = "/board", method=RequestMethod.GET)
	public String grade(HttpServletRequest request,Model model) {
		System.out.println("requestmethod.get");
		
		String id = request.getParameter("studentId");
		System.out.println("id : "+id);
		model.addAttribute("studentId",id);
		
		return "board/studentId";
		
	}
	
	
	  @RequestMapping(value = "/board", method=RequestMethod.POST) 
	  public ModelAndView grade(HttpServletRequest request) {
	  System.out.println("requestmethod.post");
	  
	  String id = request.getParameter("studentId");
	  System.out.println("id : "+id);
	 
	  ModelAndView mv = new ModelAndView(); 
	  mv.setViewName("board/studentId");
	  mv.addObject("studentId",id);
	 
	 return mv; 
	  }
	 
}
