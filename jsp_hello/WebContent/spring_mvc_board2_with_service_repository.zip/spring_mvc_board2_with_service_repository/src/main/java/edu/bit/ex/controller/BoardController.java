package edu.bit.ex.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.bit.ex.service.BoardService;
import edu.bit.ex.vo.BoardVO;

@Controller
public class BoardController {

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	// new�� ��ü�������� �ϱ� ���� @autowired ���
	// �̿Ͱ��� �ڵ������� ��ü�� ������ְ� ����� �� �ְ� ���ִ� ���� �����������̶�� ��
	@Autowired
	private BoardService boardService;

	@RequestMapping("/list")
	public String list(Model model) {
		logger.info("list");

		List<BoardVO> dtos = boardService.getBoardList();
		model.addAttribute("list", dtos);

		return "list";
	}

	// command ��ü
	@RequestMapping("/content_view")
	public String content_view(BoardVO boardVO, Model model) { // student�� ���θ� �߾���...
		logger.info("content_view");

		String bId = String.valueOf(boardVO.getbId());

		logger.info(bId);

		boardVO = boardService.getBoardVO(bId);
		model.addAttribute("content_view", boardVO);

		return "content_view";
	}

	@RequestMapping("/delete")
	public String delete(BoardVO boardVO, Model model) {
		logger.info("delete");

		String bId = String.valueOf(boardVO.getbId());
		logger.info(bId);

		boardService.delBoardVO(bId);

		return "redirect:list";
	}

	@RequestMapping("/write_view")
	public String write_view(Model model) {
		logger.info("write_view");

		return "write_view";
	}

	@RequestMapping("/write")
	public String write(BoardVO boardVO, Model model) {
		logger.info("write");

		String bName = boardVO.getbName();
		String bTitle = boardVO.getbTitle();
		String bContent = boardVO.getbContent();

		boardService.boardWrite(bName, bTitle, bContent);
		//�̷� ����� �ִ�
		//boardService.getWriteVO(boardVO.getbName(), boardVO.getbTitle(), boardVO.getbContent());
		return "redirect:list";
	}
	
	@RequestMapping("/modify")
	public String modify(BoardVO boardVO, Model model) {
		logger.info("modify");

		String bId = String.valueOf(boardVO.getbId());
		logger.info(bId);
		String bName = boardVO.getbName();
		String bTitle = boardVO.getbTitle();
		String bContent = boardVO.getbContent();

		boardService.modBoardVO(bId,bName, bTitle, bContent);

		return "redirect:list";
	}
	
	@RequestMapping("/reply_view")
	public String reply_view(BoardVO boardVO, Model model) {
		logger.info("reply_view");

		String bId = String.valueOf(boardVO.getbId());
		logger.info(bId);

		boardVO=boardService.replyViewVO(bId);
		model.addAttribute("reply_view", boardVO);

		return "reply_view";
	}
	
	@RequestMapping("/reply")
	public String reply(BoardVO boardVO, Model model) {
		logger.info("reply");

		String bId = String.valueOf(boardVO.getbId());
		String bName = boardVO.getbName();
		String bTitle = boardVO.getbTitle();
		String bContent = boardVO.getbContent();
		String bGourp = String.valueOf(boardVO.getbGroup());
		String bStep = String.valueOf(boardVO.getbStep());
		String bIndent = String.valueOf(boardVO.getbIndent());
		
		logger.info(bId);

		boardService.replyVO(bId,bName,bTitle,bContent,bGourp,bStep,bIndent);

		return "redirect:list";
	}
	
}
