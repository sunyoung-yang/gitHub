package edu.bit.ex.service;

import java.util.List;


import edu.bit.ex.vo.BoardVO;


public interface BoardService {
	
	List<BoardVO> getBoardList();
	BoardVO getBoardVO(String bId);
	void delBoardVO(String bId);
	void boardWrite(String bName, String bTitle, String bContent);
	void modBoardVO(String bId, String bName, String bTitle, String bContent);
	BoardVO replyViewVO(String bId);
	void replyVO(String bId, String bName, String bTitle, String bContent, String bGourp, String bStep, String bIndent);

}
