interface IStack{
    boolean isEmpty();
    boolean isFull();
    void push(int item);
    int pop();
    int peek();
    void clear();
}

public class StackArray implements IStack{
    
    private int top;
    private int stackSize;
    private int stackArr[];
    
    public StackArray(int stackSize) {
    	top=-1;		//���� ���ΰ� ����ִٸ� top=-1
    	this.stackSize=stackSize;
    	stackArr = new int[this.stackSize];//�ν��Ͻ� ����
    }
    public boolean isEmpty() {
    	return(top==-1);
    }
    public boolean isFull() {
    	return (top ==this.stackSize-1);
    }
    public void push(int item) {
    	if(isFull()) {
    		System.out.println("no vacancy");
    	}else
    		stackArr[++top]=item;
    	System.out.println("inserte item is "+item);
    }
    public int pop() { //�ֻ��� ����Ÿ ���� �� ����
    	if(isEmpty()) {
    		System.out.println("peeking fail stack is empty");
    		return 0;
    }else {
    	System.out.println("deleted item is"+stackArr[top]);
    	
    	return stackArr[--top];
    }
    }
    
    public int peek() {  //�ֻ��� ������ ����
    	if(isEmpty()) {
    		System.out.println("peeking fail stack is empty");
    		return 0;
    	} else {
    		System.out.println("peeked item is"+stackArr[top]);
    		
    		return stackArr[top];
    	}
    }
    public void clear() {
    	if(isEmpty()) {
    		System.out.println("stack is already empty");
    	} else {
    		top=-1;
    		stackArr = new int[this.stackSize];
    		System.out.println("stack is clear");
    	}
    }
    public void printStack() {
    	if(isEmpty()) {
    		System.out.println("stack is empty");
    	}else {
    		System.out.print("stack elements : ");
    		for(int i=0;i<=top;i++) {
    			System.out.println(stackArr[i]+" ");
    		}
    		System.out.println();
    	}
    }
public static void main(String[] args) {
		int stackSize=5;
		StackArray arrstack = new StackArray(stackSize);
		
		arrstack.push('A');
		arrstack.printStack();
        
		arrstack.push('B');
		arrstack.printStack();
        
		arrstack.push('C');
		arrstack.printStack();
        
		arrstack.pop();
		arrstack.printStack();
        
		arrstack.pop();
		arrstack.printStack();
        
		arrstack.peek();
		arrstack.printStack();
        
		arrstack.clear();
		arrstack.printStack();

}
	}

